package com.hspedu.encap.aides;

public interface boss1 {
    public void build();//新建房间
    public  void dismantle();//拆除房间
    public void fitment();//装修房间
    public void revise();//修改各类房间数量
    public void bossview();//界面


}
