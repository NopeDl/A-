package com.hspedu.encap.aides;

public interface customer1 {
    public  void view();//获取房间类型及其数量
    public void operate();//开房
    public void Check();//退房
    public void recharge();//充值
    public void customerView();//界面


}
