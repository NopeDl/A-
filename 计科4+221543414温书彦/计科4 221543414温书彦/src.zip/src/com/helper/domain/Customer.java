package com.wenshuyan.helper.domain;

/**
 * ClassName:Account
 * Package:PACKAGE_NAME
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/18 - 17:43
 * @Version: v1.0
 */
public class Customer {
    private String name;//帐号昵称
    private final int ID;//常量 账号ID
    private String password = "000000";//账号密码
    private double balance = 0.0;//账号余额
    private boolean vip = false;//是否是会员
    private double discount = 1.0;//折扣
    private Room room;//入住房间
    private int day;//入住天数
    private static int firstId = 0;//初始id(管理员id)

    public Customer() {
        ID = firstId++;
    }

    public Customer(String name, String password) {
        this.name = name;
        this.password = password;
        ID = firstId++;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public int getID() {
        return ID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
}
