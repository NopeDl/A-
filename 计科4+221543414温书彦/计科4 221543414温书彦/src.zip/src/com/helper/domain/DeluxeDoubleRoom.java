package com.wenshuyan.helper.domain;

/**
 * ClassName:DeluxeDoubleRoom
 * Package:com.wenshuyan.helper.domain
 * Description:豪华双人间
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 0:22
 * @Version: v1.0
 */
public class DeluxeDoubleRoom extends Room {
    private static int number = -1;//此类型房间的所有数量（-1因为有样板房）
    private static int restNumber = -1;//此类型房间的空闲房间数量
    public DeluxeDoubleRoom(String name, double price) {
        super(name, price);
        number++;
        restNumber++;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        DeluxeDoubleRoom.number = number;
    }

    public int getRestNumber() {
        return restNumber;
    }

    public void setRestNumber(int restNumber) {
        DeluxeDoubleRoom.restNumber = restNumber;
    }

    @Override
    public void welcome(Customer cust) {
        System.out.println("欢迎 " + cust.getName() + " 入住" + getName() + ",帮帮祝您生活愉快WvW,希望您有个好梦");
    }
}
