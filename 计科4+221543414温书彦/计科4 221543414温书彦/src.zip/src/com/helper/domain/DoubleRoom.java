package com.wenshuyan.helper.domain;

/**
 * ClassName:DoubleRoom
 * Package:com.wenshuyan.helper.domain
 * Description:标准双人间
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 0:22
 * @Version: v1.0
 */
public class DoubleRoom extends Room {
    private static int number = -1;//此类型房间的所有数量
    private static int restNumber = -1;//此类型房间的空闲房间数量
    public DoubleRoom(String name, double price) {
        super(name, price);
        number++;
        restNumber++;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        DoubleRoom.number = number;
    }

    public int getRestNumber() {
        return restNumber;
    }

    public void setRestNumber(int restNumber) {
        DoubleRoom.restNumber = restNumber;
    }

    @Override
    public void welcome(Customer cust) {
        System.out.println("欢迎 " + cust.getName() + " 入住" + getName());
    }
}
