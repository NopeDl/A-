package com.wenshuyan.helper.domain;

import com.wenshuyan.helper.service.*;

import static com.wenshuyan.helper.service.Status.FREE;

/**
 * ClassName:com.wenshuyan.helper.domain.Room
 * Package:PACKAGE_NAME
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/18 - 19:10
 * @Version: v1.0
 */
public abstract class Room {
    private String name;//房间类型名称
    private double price;//每晚价格
    private static int number = 0;//此类型房间的所有数量
    private static int restNumber;//此类型房间的空闲房间数量
    private Status status = FREE;

    private Room(){

    }
    public Room(String name,double price){
        this.name = name;
        this.price = price;
    }

    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public abstract int getNumber();

    public abstract void setNumber(int number);

    public abstract int getRestNumber();

    public abstract void setRestNumber(int restNumber);


    //入住提示语
    public abstract void welcome(Customer cust);
}
