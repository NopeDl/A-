package com.wenshuyan.helper.factory;

import com.wenshuyan.helper.domain.DeluxeDoubleRoom;
import com.wenshuyan.helper.factory.Factory;

/**
 * ClassName:DeluxeDoubleRoomFactory
 * Package:com.wenshuyan.helper.service
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 1:15
 * @Version: v1.0
 */
public class DeluxeDoubleRoomFactory implements Factory {

    @Override
    public DeluxeDoubleRoom getRoom() {
        return new DeluxeDoubleRoom("豪华双人间",260.0);
    }
}
