package com.wenshuyan.helper.factory;

import com.wenshuyan.helper.domain.DeluxeSingleRoom;
import com.wenshuyan.helper.factory.Factory;

/**
 * ClassName:DeluxeSingleRoomFactory
 * Package:com.wenshuyan.helper.service
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 1:14
 * @Version: v1.0
 */
public class DeluxeSingleRoomFactory implements Factory {

    @Override
    public DeluxeSingleRoom getRoom() {
        return new DeluxeSingleRoom("豪华单人间",200.0);
    }
}
