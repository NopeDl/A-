package com.wenshuyan.helper.factory;

import com.wenshuyan.helper.domain.DoubleRoom;
import com.wenshuyan.helper.factory.Factory;

/**
 * ClassName:DoubleRoomFactory
 * Package:com.wenshuyan.helper.service
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 1:12
 * @Version: v1.0
 */
public class DoubleRoomFactory implements Factory {
    public DoubleRoom getRoom(){
        return new DoubleRoom("标准双人间",150.0);
    }
}
