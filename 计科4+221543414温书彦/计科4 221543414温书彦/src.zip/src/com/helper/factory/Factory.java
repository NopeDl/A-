package com.wenshuyan.helper.factory;

import com.wenshuyan.helper.domain.Room;

/**
 * ClassName:Factory
 * Package:com.wenshuyan.helper.service
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 1:04
 * @Version: v1.0
 */
public interface Factory {
    Room getRoom();
}

