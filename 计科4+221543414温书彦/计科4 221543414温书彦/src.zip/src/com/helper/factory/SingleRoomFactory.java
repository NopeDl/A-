package com.wenshuyan.helper.factory;

import com.wenshuyan.helper.domain.SingleRoom;
import com.wenshuyan.helper.factory.Factory;

/**
 * ClassName:SingleRoomFactory
 * Package:com.wenshuyan.helper.service
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/29 - 1:04
 * @Version: v1.0
 */
public class SingleRoomFactory implements Factory {

    public SingleRoom getRoom(){
        return new SingleRoom("标准单人间",100.0);
    }
}
