package com.wenshuyan.helper.service;

import com.wenshuyan.helper.domain.*;
import com.wenshuyan.helper.view.HelperView;

/**
 * ClassName:HelperList
 * Description: 一些主页面相关操作功能
 *
 * @Author: 温书彦
 * @Create:2023/1/18 - 22:36
 * @Version: v1.0
 */
public class HelperList {

    /**
     * 登录账号(管理员账号：0，密码：000000)
     */
    public static void logIn(){
        System.out.println("\n------------------登录界面------------------");
        HelperView view = new HelperView();
        System.out.println("请输入登录信息：");
        System.out.print("账号：>");
        int id = Utility.readInt(3);
        System.out.print("密码：>");
        String password = Utility.readString(12);
        if(Hotel.getCustomers()[id] != null){
            if(Hotel.getCustomers()[id].getPassword().equals(password)){
                HelperView.isLoop = true;
                if(id == 0){
                    System.out.println("----------------------------------------\n");
                    view.administratorView();
                }
                else{
                    System.out.println("----------------------------------------\n");
                    view.logView(Hotel.getCustomers()[id],id);
                }
            }
            else{
                System.out.println("账号或密码错误，请重新登录。");
                System.out.println("----------------------------------------\n");
            }
        }
        else{
            System.out.println("用户不存在，请重新登录。");
            System.out.println("----------------------------------------\n");
        }
        Utility.enterContinue();
    }

    /**
     * 注册账号
     */
    public static void signIn(){
        System.out.println("\n----------------注册界面----------------");
        System.out.println("请输入注册信息：");
        System.out.print("提示：昵称在5个字符以内\n昵称：>");
        String name = Utility.readString(5);
        System.out.print("提示：密码在12个字符以内\n账号密码：>");
        String passcode = Utility.readString(12);
        Customer cust = new Customer(name,passcode);
        Hotel.getCustomers()[cust.getID()] = cust;
        System.out.println("注册成功！您的账号ID是：" + cust.getID());
        System.out.println("请登录账号");
        System.out.println("----------------------------------------");
        Utility.enterContinue();
    }

    /**
     * 修改账号密码
     */
    public static boolean changePassword(Customer cust){
        boolean isLoop;//若密码更改成功需重新登录账号
        System.out.println("\n------------------修改账号密码界面------------------");
        System.out.print("请输入旧密码：>");
        String password = Utility.readString(12);
        if(Hotel.getCustomers()[cust.getID()].getPassword().equals(password)){
            System.out.print("请输入新密码：>");
            String newPassword1 = Utility.readString(12);
            System.out.print("再次输入新密码：>");
            String newPassword2 = Utility.readString(12);
            if(newPassword1.equals(newPassword2)){
                Hotel.getCustomers()[cust.getID()].setPassword(newPassword1);
                System.out.println("请确认是否修改密码(Y/N)：>");
                char isChange = Utility.readConfirmSelection();
                if(isChange == 'Y'){
                    System.out.println("修改成功，请重新登录。");
                    isLoop = false;
                }
                else{
                    System.out.println("已取消修改密码！");
                    isLoop = true;
                }
            }
            else{
                System.out.println("两次新密码不同，请重新输入！");
                isLoop = true;
            }
        }
        else{
            System.out.println("密码错误！");
            isLoop = true;
        }
        System.out.println("----------------------------------------\n");
        Utility.enterContinue();
        return isLoop;
    }

    /**
     * 是否退出账号
     */
    public static void isExit(){
        System.out.println("\n------------------退出界面------------------");
        System.out.print("请确认是否退出账号(Y/N):");
        char isExit = Utility.readConfirmSelection();
        if(isExit == 'Y') {
            HelperView.isLoop = false;
            System.out.println("--------------退出成功-------------\n");
        }
    }

    /**
     * 账号余额充值
     */
    public static void recharge(Customer cust){
        System.out.println("\n------------------充值界面------------------");
        System.out.println("您的余额为：" + cust.getBalance());
        System.out.print("提示：单次充值上限为9999元\n请输入想充值金额：");
        double amount = Utility.readDouble(4);
        double newBalance = cust.getBalance() + amount;
        cust.setBalance(newBalance);
        System.out.println("充值成功，您的余额为：" + cust.getBalance());
        System.out.println("----------------------------------------\n");
        Utility.enterContinue();
    }


    /**
     *办理会员
     */
    public static void becomeVip(Customer cust){
        System.out.println("\n------------------会员办理界面------------------");
        System.out.print("VIP月卡：50元/月\n办理后，会员期间可享受8折开房折扣\n是否充值为会员(Y/N):");
        char isVip = Utility.readConfirmSelection();
        if(isVip == 'Y'){
            if(cust.getBalance() >= 50){
                cust.setVip(true);
                cust.setDiscount(0.8);
                cust.setBalance(cust.getBalance() - 50);
                System.out.println("会员办理成功！");
            }else
                System.out.println("余额不足，请先充值");
        }else
            System.out.println("取消办理成功！");
        System.out.println("----------------------------------------\n");
        Utility.enterContinue();
    }

}
