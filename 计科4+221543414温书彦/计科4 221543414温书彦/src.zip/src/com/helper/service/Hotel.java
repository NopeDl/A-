package com.wenshuyan.helper.service;

import com.wenshuyan.helper.domain.Customer;
import com.wenshuyan.helper.domain.DoubleRoom;
import com.wenshuyan.helper.domain.Room;
import com.wenshuyan.helper.domain.SingleRoom;
import com.wenshuyan.helper.factory.DeluxeDoubleRoomFactory;
import com.wenshuyan.helper.factory.DeluxeSingleRoomFactory;
import com.wenshuyan.helper.factory.DoubleRoomFactory;
import com.wenshuyan.helper.factory.SingleRoomFactory;

import java.sql.SQLOutput;

/**
 * ClassName:com.wenshuyan.helper.service.Hotel
 * Package:PACKAGE_NAME
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/18 - 16:06
 * @Version: v1.0
 */
public class Hotel {
    private static Room[] roomType;
    private static Room[] rooms;//旅馆所有房间
    private static Customer[] customers;//小帮手的用户数组

    public static Room[] getRoomType() {
        return roomType;
    }

    public static void setRoomType(Room[] roomType) {
        Hotel.roomType = roomType;
    }

    public static Room[] getRooms() {
        return rooms;
    }

    public static void setRooms(Room[] rooms) {
        Hotel.rooms = rooms;
    }

    public static Customer[] getCustomers() {
        return customers;
    }

    public static void setCustomers(Customer[] customers) {
        Hotel.customers = customers;
    }

    /**
     * 展示所有类型房间的信息
     **/
    public void allRoomList(){
        System.out.println("\n----------------------房间信息----------------------");
        for(int i = 0;i < getRoomType().length;i++){
            System.out.println("房间类型：" + getRoomType()[i].getName() + "\t每晚价格：" + getRoomType()[i].getPrice()
             + "\t房间数量：" + getRoomType()[i].getNumber() + "\t空闲房间数量：" + getRoomType()[i].getRestNumber());
        }
        System.out.println("-----------------------------------------------------\n");
        Utility.enterContinue();
    }
    /**
     * 展示空闲房间相关信息
     **/
    public void restRoomList(){
        System.out.println("\n------------------空闲房间信息------------------");
        for(int i = 0;i < getRoomType().length;i++){
            System.out.println("房间类型：" + getRoomType()[i].getName() + "\t每晚价格："
                    + getRoomType()[i].getPrice() + "\t空闲房间数量：" + getRoomType()[i].getRestNumber());
        }
        System.out.println("----------------------------------------------\n");
        Utility.enterContinue();
    }
    /**
     * 查询所有用户的入住信息
     **/
    public void allCustomerList(){
        System.out.println("\n-----------------用户入住信息------------------");
        System.out.println("用户名称\t\t用户ID\t\t入住房间类型\t\t入住天数");
        for(int i = 0;getCustomers()[i] !=null;i++){
            System.out.print(getCustomers()[i].getName() + "\t\t" + getCustomers()[i].getID());
                    if(getCustomers()[i].getRoom() != null){
                        System.out.println("\t\t" + getCustomers()[i].getRoom().getName() + "\t\t" + getCustomers()[i].getDay());
                    }
                    else
                        System.out.println("\t\t未入住");
        }
        System.out.println("----------------------------------------------\n");
        Utility.enterContinue();
    }

    /**
     * 查看用户房卡
     **/
    public void getCustomerCard(int index){
        System.out.println("\n------------------我的房卡------------------");
        System.out.println("昵称：" + getCustomers()[index].getName() + "\tID:" + getCustomers()[index].getID() + "\t余额：" + getCustomers()[index].getBalance());
        if(getCustomers()[index].getRoom() == null)
            System.out.println("您还未入住");
        else
            System.out.println("入住房间类型：" + getCustomers()[index].getRoom().getName() + "\t入住天数：" + getCustomers()[index].getDay());
        System.out.println("----------------------------------------------\n");
        Utility.enterContinue();
    }

    /**
     * 旅馆收到顾客提出需要更多单人间的需求后，会马上建造单人间，提高单人间总数量
     **/
    public boolean singleRoomDemand(){
        boolean isBulid = false;
        int i;
        for(i = 0;i < getRooms().length;i++){
            if(getRooms()[i] == null){
                getRooms()[i] = new SingleRoom("标准单人间",100.0);
                isBulid = true;
                break;
            }
        }
        return isBulid;
    }

    /**
     * 建造房间
     **/
    public void build(){
        System.out.println("\n------------------建造房间------------------");
        System.out.println("可建造的房间类型有：");
        int i;
        for(i = 0;i < getRoomType().length;i++){
            System.out.println(i+1 + "、" + getRoomType()[i].getName());
        }
        System.out.print("请选择建造类型：>");
        int option = Utility.readIntSelection(4);//选择1-4类型的房间
        System.out.print("请确认是否建造\"" + getRoomType()[option - 1].getName() + "\"一间(Y/N)：>");
        char isBuild = Utility.readConfirmSelection();
        if (isBuild == 'Y') {
            int j = 0;
            while(getRooms()[j] != null)
                j++;
            if(option == 1)
                getRooms()[j] = new SingleRoomFactory().getRoom();//工厂模式获得房间
            if(option == 2)
                getRooms()[j] = new DoubleRoomFactory().getRoom();
            if(option == 3)
                getRooms()[j] = new DeluxeSingleRoomFactory().getRoom();
            if(option == 4)
                getRooms()[j] = new DeluxeDoubleRoomFactory().getRoom();
            System.out.println("------------------建造成功------------------\n");
        }
        else
            System.out.println("------------------已取消建造------------------\n");
        Utility.enterContinue();
    }

    /**
     * 拆除房间
     **/
    public void demolish(){
        System.out.println("\n------------------拆除房间------------------");
        System.out.println("可拆除的房间类型及其空闲数量：");
        int i;
        for(i = 0;i < getRoomType().length;i++){
            System.out.println(i+1 + "、" + getRoomType()[i].getName() + "\t空闲房间数量：" + getRoomType()[i].getRestNumber());//正在入住的房间不好拆除
        }
        System.out.print("请选择想要拆除的房间类型：>");
        int option = Utility.readIntSelection(4);//选择1-4类型的房间
        if(getRoomType()[option - 1].getRestNumber() <= 0)
            System.out.println("此类型房间无空闲房间，无法拆除。");
        else{
            System.out.print("请确认是否拆除一间\"" + getRoomType()[option - 1].getName() + "\"(Y/N)：>");
            char isDemolish = Utility.readConfirmSelection();
            if (isDemolish == 'Y') {
                    int j = findRestRoom(option);
                    getRooms()[j].setNumber(getRooms()[j].getNumber() - 1);
                    getRooms()[j].setRestNumber(getRooms()[j].getRestNumber() - 1);
                    getRooms()[j] = null;
                //从房间数组后面开始找到一间符合条件的房间进行拆除
                    for(;getRooms()[j + 1] != null;j++){
                        getRooms()[j] = getRooms()[j+1];
                    }//拆除后将房间数组往前补
                System.out.println("------------------拆除成功------------------\n");
            }
            else
                System.out.println("------------------已取消拆除------------------\n");
        }
        Utility.enterContinue();
    }

    /**
     * 装修房间
     **/
    public void renovation() {
        System.out.println("\n------------------装修房间------------------");
        System.out.println("可进行装修的房间类型及其空闲数量：");
        int i;
        for (i = 0; i < getRoomType().length; i++) {
            System.out.println(i + 1 + "、" + getRoomType()[i].getName() + "\t空闲房间数量：" + getRoomType()[i].getRestNumber());//正在入住的房间不好装修
        }
        System.out.print("请选择想要装修的房间类型：>");
        int option = Utility.readIntSelection(4);//选择1-4类型的房间
        if (getRoomType()[option - 1].getRestNumber() <= 0)
            System.out.println("此类型房间无空闲房间，无法装修。");
        else {
            int j = findRestRoom(option);//符合条件的房间号
            System.out.println("可选择以下几种类型进行装修：");
            for (i = 0; i < getRoomType().length; i++) {
                if (i != option - 1)
                    System.out.println(getRoomType()[i].getName());
            }//展示可装修的房间类型
            System.out.print("请输入想要装修成的房间类型名字：>");
            while(true){
                String renovationRoom = Utility.readString(5);
                boolean isFalse = true;//判断输入的房间类型名字是否正确
                for (i = 0; i < getRoomType().length; i++) {
                    if (i != option - 1)
                        if (renovationRoom.equals(getRoomType()[i].getName()))
                            isFalse = false;
                }
                if (isFalse == false) {//符合条件后进行装修，即输入正确
                    System.out.print("请确认是否将\"" + getRoomType()[option - 1].getName() + "\"装修成" + "\"" + renovationRoom + "\"(Y/N)：>");
                    char isDemolish = Utility.readConfirmSelection();
                    if (isDemolish == 'Y') {
                        getRooms()[j].setNumber(getRooms()[j].getNumber() - 1);
                        getRooms()[j].setRestNumber(getRooms()[j].getRestNumber() - 1);
                        getRooms()[j] = null;//把旧房间拆除
                        switch (renovationRoom) {
                            case "标准单人间":
                                getRooms()[j] = new SingleRoomFactory().getRoom();
                                break;
                            case "标准双人间":
                                getRooms()[j] = new DoubleRoomFactory().getRoom();
                                break;
                            case "豪华单人间":
                                getRooms()[j] = new DeluxeSingleRoomFactory().getRoom();
                                break;
                            case "豪华双人间":
                                getRooms()[j] = new DeluxeDoubleRoomFactory().getRoom();
                                break;
                            }
                        System.out.println("-----------------装修成功------------------\n");
                        break;
                    } else{
                        System.out.println("------------------已取消装修------------------\n");
                        break;
                    }
                } else
                    System.out.println("输入的房间类型错误,请重新输入：");
            }
        }
        Utility.enterContinue();
    }

    /**
     * 开房间
     **/
    public void checkInRoom(int index){
        System.out.println("\n------------------入住房间------------------");
        if(getCustomers()[index].getRoom() != null){
            System.out.println("您已入住");
            System.out.println("----------------------------------------------\n");
            Utility.enterContinue();
            return;
        }
        if(getRoomType()[0].getRestNumber() <= 0){
            System.out.print("已发现无空闲标准单人间，是否向旅馆提出建造单人间需求(Y/N)：>");
            char isBulid = Utility.readConfirmSelection();
            if(isBulid == 'Y'){
                boolean isBulidSuccee = singleRoomDemand();
                if(isBulidSuccee == true)
                    System.out.println("已建造好一间标准单人间！\n");
                else if(isBulidSuccee == false)
                    System.out.println("旅馆建造已达上限，无法再建造房间。");
            }else {
                System.out.println("已取消提出需求！");
            }
        }
        int i;
        for (i = 0; i < getRoomType().length; i++) {
            System.out.println(i + 1 + "、" + getRoomType()[i].getName());
        }
        System.out.print("请输入想要入住的房间类型：>");
        int option = Utility.readIntSelection(i);//选择房间类型
        if(getRoomType()[option - 1].getRestNumber() <= 0){
            System.out.println("很抱歉，此类型已无空闲房间。");
            System.out.println("----------------------------------------------\n");
        }
        else{
            System.out.print("提示：单次最多可入住9天\n请输入想入住天数：>");
            int liveDay = Utility.readInt(1);
            double originalPrice = getRoomType()[option - 1].getPrice()*liveDay;//未折扣入住金额
            double price = getRoomType()[option - 1].getPrice()*liveDay*getCustomers()[index].getDiscount();//真正的入住金额
            if(Hotel.getCustomers()[index].isVip() == true)
                System.out.println("入住房间类型：" + getRoomType()[option - 1].getName() + "\t入住天数：" +
                        liveDay + "\t入住金额：" + price + "(VIP已尊享八折优惠,原价：" + originalPrice + ")");
            else
                System.out.println("入住房间类型：" + getRoomType()[option - 1].getName() + "\t入住天数：" +
                        liveDay + "\t入住金额：" + price + "(成为会员可享八折优惠)");
            System.out.print("确认入住(Y/N)：>");
            char isCheckIn = Utility.readConfirmSelection();
            if(isCheckIn == 'Y'){
                if(getCustomers()[index].getBalance() >= price){
                    try{
                        getCustomers()[index].setRoom(getRooms()[findRestRoom(option)]);//入住房间
                    }catch (ArrayIndexOutOfBoundsException e){
                        System.out.println("房间已满，入住失败。");
                        System.out.println("----------------------------------------------\n");
                        Utility.enterContinue();
                        return;
                    }
                    getCustomers()[index].setDay(liveDay);//设置入住天数
                    getCustomers()[index].getRoom().setStatus(Status.BUSY);//将用户入住房间标为已入住
                    getCustomers()[index].getRoom().setRestNumber(getCustomers()[index].getRoom().getRestNumber() - 1);//该客户入住后房间空闲数量-1
                    getCustomers()[index].getRoom().welcome(getCustomers()[index]);//欢迎提示语
                    getCustomers()[index].setBalance(getCustomers()[index].getBalance()-price);//扣除金额
                    System.out.println("----------------------------------------------\n");
                }
                else{
                    System.out.println("余额不足，请先充值");
                    System.out.println("----------------------------------------------\n");
                }
            }
            else
                System.out.println("------------------已取消入住------------------\n");
        }
        Utility.enterContinue();
    }
    /**
     * 退房
     **/
    public void checkOutRoom(int index){
        System.out.println("\n------------------退房------------------");
        if(getCustomers()[index].getRoom() == null)
            System.out.println("您未办理入住");
        else{
            System.out.println("您入住的房间类型是：" + getCustomers()[index].getRoom().getName());
            System.out.print("请确认是否退房(Y/N)：>");
            char isCheckIn = Utility.readConfirmSelection();
            if(isCheckIn == 'Y'){
                getCustomers()[index].getRoom().setStatus(Status.FREE);//将入住房间标为未入住状态
                getCustomers()[index].getRoom().setRestNumber(getCustomers()[index].getRoom().getRestNumber() + 1);//该客户入住后房间空闲数量+1
                getCustomers()[index].setRoom(null);//清除用户入住房间信息
                System.out.println("退房成功，期待下次入住！");
            }else {
                System.out.println("已取消退房！");
            }
        }
        System.out.println("----------------------------------------------\n");
        Utility.enterContinue();
    }
    /**
     * 寻找符合条件的房间，仅在类内部使用
     **/
    private int findRestRoom(int option){
        int j;
        boolean isFind = false;
        for (j = (getRooms().length - 1);j >= 0; j--) {
            if(getRooms()[j] != null)
                if (getRooms()[j].getName().equals(getRoomType()[option - 1].getName()) && getRooms()[j].getStatus().equals(Status.FREE)) {
                    isFind = true;
                    break;
                }
        }
        if(isFind == false){
            return -1;//用负数表示没有找到符合条件的房间
        }
        return j;
    }
}
