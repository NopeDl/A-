package com.wenshuyan.helper.service;

/**
 * ClassName:Status
 * Package:com.wenshuyan.helper.service
 * Description:房间的入住状态
 *
 * @Author: 温书彦
 * @Create:2023/1/30 - 10:26
 * @Version: v1.0
 */
public class Status {
    private final String NAME;
    private Status(String name){
        this.NAME = name;
    }

    public static final Status FREE = new Status("FREE");//空闲未入住
    public static final Status BUSY = new Status("BUSY");//已有人入住

    public String getNAME() {
        return NAME;
    }
}
