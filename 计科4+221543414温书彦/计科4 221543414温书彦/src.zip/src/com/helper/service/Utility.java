package com.wenshuyan.helper.service;

import java.util.*;

/**
 * ClassName:Utility
 * Description:将不同的输入功能封装为方法
 * @Author: 温书彦
 * @Create:2023/1/18 - 21:13
 * @Version: v1.0
 */
public class Utility {
    private final static Scanner scanner = new Scanner(System.in);

    /**
     * 可输入1-max(1-9)的数字用于各种界面的选择操作，并以char类型作为返回值
     **/
    public static char readCharSelection(int max){
        String line = "";
        char c = '0';
        while(scanner.hasNextLine()){
            line = scanner.nextLine();
            if(line.length() == 1){
                try{
                    int i = Integer.parseInt(line);
                    if(i >= 1 && i <= max){
                        c = line.charAt(0);
                        break;
                    }else{
                        System.out.print("提示：只能输入选项数字！\n输入错误，请重新输入：");
                    }
                }catch(NumberFormatException e){
                    System.out.print("提示：只能输入选项数字！\n输入错误，请重新输入：");
                }
            }else{
                System.out.print("提示：只能输入长度为一位的数！\n输入错误，请重新输入：");
            }
        }
        return c;
    }
    /**
     * 用于输入1-max(1-9)中的任意数字作为各种界面的选择操作，并以int类型作为返回值
     */
    public static int readIntSelection(int max) {
        String line = "";
        int i = 0;
        while(scanner.hasNextLine()){
            line = scanner.nextLine();
            if(line.length() == 1){
                try{
                    i = Integer.parseInt(line);
                    if(i >= 1 && i <= max){
                        break;
                    }else{
                        System.out.print("提示：只能输入选项数字！\n输入错误，请重新输入：");
                    }
                }catch(NumberFormatException e){
                    System.out.print("提示：只能输入选项数字！\n输入错误，请重新输入：");
                }
            }else{
                System.out.print("提示：只能输入长度为一位的数！\n输入错误，请重新输入：");
            }
        }
        return i;
    }

    /**
     * 读取一个长度不超过limit位的整数，并将其作为返回值。
     */
    public static int readInt(int limit) {
        String line = "";
        int i = 0;
        while(scanner.hasNextLine()){
            line = scanner.nextLine();
            if(line.length() >= 1 && line.length() <= limit){
                try{
                    i = Integer.parseInt(line);
                    break;
                }catch(NumberFormatException e){
                    System.out.print("提示：只能输入长度不超过" + limit + "位的整数！\n输入错误，请重新输入：");
                }
            }else{
                System.out.print("提示：只能输入长度不超过" + limit + "位的整数！\n输入错误，请重新输入：");
            }
        }
        return i;
    }
    /**
     * 读取一个长度不超过limit位的双精度浮点型用于充值金额，并作为返回值。
     */
    public static double readDouble(int limit) {
        String line = "";
        double d = 0.0;
        while(scanner.hasNextLine()){
            line = scanner.nextLine();
            if(line.length() >= 1 && line.length() <= limit){
                try{
                    d = Double.parseDouble(line);
                    break;
                }catch(NumberFormatException e){
                    System.out.print("提示：只能输入长度不超过" + limit + "位的小数！\n输入错误，请重新输入：");
                }
            }else{
                System.out.print("提示：只能输入长度不超过" + limit + "位的小数！\n输入错误，请重新输入：");
            }
        }
        return d;
    }

    /**
     * 从键盘读取一个长度不超过limit的字符串，并将其作为方法的返回值。
     */
    public static String readString(int limit) {
        String line = "";
        double d = 0.0;
        while(scanner.hasNextLine()){
            line = scanner.nextLine();
            if(line.length() >= 1 && line.length() <= limit){
                break;
            }else if(line.length() == 0){
                System.out.println("提示：输入长度过短，请重新输入：");
            } else{
                System.out.print("提示：只能输入长度不超过" + limit + "位的字符串！\n输入错误，请重新输入：");
            }
        }
        return line;
    }

    /**
     * 用于确认选择的输入。该方法从键盘读取‘Y’或’N’，并将其作为方法的返回值。
     */
    public static char readConfirmSelection() {
        String line = "";
        char c = '0';
        while(scanner.hasNextLine()){
            line = scanner.nextLine().toUpperCase();//将字符转成大写
            if(line.length() == 1){
                c = line.charAt(0);
                if (c == 'Y' || c == 'N')
                    break;
                else
                    System.out.print("提示：只能输入Y/N!\n输入错误，请重新输入：");
            }else{
                System.out.print("提示：只能输入Y/N！\n输入错误，请重新输入：");
            }
        }
        return c;
    }
/**
 * 用于执行下一步操作
 **/
    public static void enterContinue(){
        System.out.print("按回车键继续……");
        String line = scanner.nextLine();
    }

}

