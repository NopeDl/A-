package com.wenshuyan.helper.view;

import com.wenshuyan.helper.domain.*;
import com.wenshuyan.helper.factory.DeluxeDoubleRoomFactory;
import com.wenshuyan.helper.factory.DeluxeSingleRoomFactory;
import com.wenshuyan.helper.factory.DoubleRoomFactory;
import com.wenshuyan.helper.factory.SingleRoomFactory;
import com.wenshuyan.helper.service.Utility;
import com.wenshuyan.helper.service.HelperList;
import com.wenshuyan.helper.service.Hotel;

/**
 * ClassName:com.wenshuyan.helper.view.HelperView
 * Package:PACKAGE_NAME
 * Description:
 *
 * @Author: 温书彦
 * @Create:2023/1/18 - 16:38
 * @Version: v1.0
 */

public class HelperView {
    private char option;//选择的操作数
    public static boolean isLoop = true;//是否循环登录账号界面
    //已登录界面
    public void logView(Customer cust, int index){
        Hotel hotel = new Hotel();
        for(;isLoop;){
            System.out.println("\n******************欢迎使用旅馆小帮手******************");
            if (cust.isVip() == true)
                System.out.println("欢迎会员：" + cust.getName() + "\t当前余额：" + cust.getBalance() +
                        "\t享受折扣：" + (int)(cust.getDiscount()*10) + "折" + " \tID：" + cust.getID());
            else{
                System.out.println("欢迎用户：" + cust.getName() + "\t当前余额：" + cust.getBalance() + "\tID：" + cust.getID());
            }
            System.out.println("------------------1、查看空闲余" +
                    "房------------------");
            System.out.println("------------------2、开房------------------");
            System.out.println("------------------3、退房------------------");
            System.out.println("------------------4、查看我的房卡------------------");
            System.out.println("------------------5、充值------------------");
            System.out.println("------------------6、更改密码------------------");
            if(cust.isVip() == false){
                System.out.println("------------------7、成为会员------------------");
                System.out.println("------------------8、退出登录------------------");
            } else
                System.out.println("------------------7、退出登录------------------");
            System.out.println("***************************************************");
            System.out.print("请选择操作数:>");
            if(cust.isVip() == false)
                option = Utility.readCharSelection(8);
            else
                option = Utility.readCharSelection(7);
            if(option == '1')
                hotel.restRoomList();
            if(option == '2')
                hotel.checkInRoom(cust.getID());
            if(option == '3')
                hotel.checkOutRoom(cust.getID());
            if(option == '4')
                hotel.getCustomerCard(cust.getID());
            if(option == '5')
                HelperList.recharge(cust);
            if(option == '6')
                isLoop = HelperList.changePassword(cust);//若密码更改成功需退出登录界面重新登录
            if(cust.isVip() == false){
                if(option == '7')
                    HelperList.becomeVip(cust);
                if(option == '8')
                    HelperList.isExit();
            } else
                if(option == '7')
                    HelperList.isExit();
        }
    }
    //未登录界面(已完成)
    public void notLogView() {
        boolean isLoopHelper = true;//是否循环小帮手
        for(;isLoopHelper;){
            System.out.println("\n******************欢迎使用旅馆小帮手******************");
            System.out.println("欢迎用户,请登录。");
            System.out.println("------------------1、登录------------------");
            System.out.println("------------------2、注册------------------");
            System.out.println("------------------3、退出------------------");
            System.out.println("***************************************************");
            System.out.print("请选择操作数:>");
            option = Utility.readCharSelection(3);
            if (option == '1')
                HelperList.logIn();
            if (option == '2')
                HelperList.signIn();
            if (option == '3'){
                System.out.print("请确认是否退出旅馆小帮手(Y/N):");
                char isExit = Utility.readConfirmSelection();
                if(isExit == 'Y') {
                    isLoopHelper = false;
                    System.out.println("\n--------------欢迎下次使用-------------");
                }
            }
        }
    }
    //管理员界面
    public void administratorView(){
        Hotel hotel = new Hotel();
        for(;isLoop;){
            System.out.println("\n******************欢迎使用旅馆小帮手******************");
            System.out.println("欢迎管理员");
            System.out.println("------------------1、查看所有房间信息------------------");
            System.out.println("------------------2、查看所有用户入住信息------------------");
            System.out.println("------------------3、建造房间------------------");
            System.out.println("------------------4、拆除房间------------------");
            System.out.println("------------------5、装修房间------------------");
            System.out.println("------------------6、退出登录------------------");
            System.out.println("***************************************************");
            System.out.print("请选择操作数:>");
            option = Utility.readCharSelection(6);
            if(option == '1')
                hotel.allRoomList();
            if(option == '2')
                hotel.allCustomerList();
            if(option == '3')
                hotel.build();
            if(option == '4')
                hotel.demolish();
            if(option == '5')
                hotel.renovation();
            if(option == '6')
                HelperList.isExit();
        }

    }

    public static void main(String[] args) {
        Hotel.setRooms(new Room[30]);//旅馆最多可有30间房间
        int i = 0;
        for(int j = 0;j < 5;i++,j++){
            Hotel.getRooms()[i] = new SingleRoomFactory().getRoom();
        }//旅馆初始有5间单人间
        for(int j = 0;j < 3;i++,j++){
            Hotel.getRooms()[i] = new DoubleRoomFactory().getRoom();
        }//旅馆初始有3间双人间
        for(int j = 0;j < 2;i++,j++){
            Hotel.getRooms()[i] = new DeluxeSingleRoomFactory().getRoom();
        }//旅馆初始有2间豪华单人间
        Hotel.getRooms()[i] = new DeluxeDoubleRoomFactory().getRoom();//旅馆初始有1间豪华双人间

        Hotel.setRoomType(new Room[4]);//将四种房间类型记录在roomType数组中(相当于样板房)
        Hotel.getRoomType()[0] = new SingleRoomFactory().getRoom();
        Hotel.getRoomType()[1] = new DoubleRoomFactory().getRoom();
        Hotel.getRoomType()[2] = new DeluxeSingleRoomFactory().getRoom();
        Hotel.getRoomType()[3] = new DeluxeDoubleRoomFactory().getRoom();

        Hotel.setCustomers(new Customer[100]);//小帮手最多可注册100名用户
        Hotel.getCustomers()[0] = new Customer("管理员","000000");//设置管理员账户
        HelperView helperView = new HelperView();
        helperView.notLogView();//入口
    }
}
