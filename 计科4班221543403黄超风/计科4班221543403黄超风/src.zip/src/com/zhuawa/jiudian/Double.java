package com.zhuawa.jiudian;

public class Double extends Room {

    public Double() {
    }

    public Double(int price, String name) {
        super(price, name);
    }


}
