package com.zhuawa.jiudian;

public class Single extends Room {
    public Single() {
    }

    public Single(int price, String name) {
        super(price, name);
    }

}
