package com.zhuawa.jiudian;

public class Suite extends Room {
    public Suite() {
    }

    public Suite(int price, String name) {
        super(price, name);
    }


}
