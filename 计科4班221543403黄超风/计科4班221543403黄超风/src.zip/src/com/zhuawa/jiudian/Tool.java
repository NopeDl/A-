package com.zhuawa.jiudian;

import sun.text.resources.cldr.ia.FormatData_ia;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;

        //顾客操作的分步流程
public abstract class Tool {
    /**
     * 根据卡号查询出一个账户对象出来
     *
     * @param cardId   卡号
     * @param accounts 全部账户的集合
     * @return 账户对象 | null
     */
    public static Account getAccountByCardId(String cardId, ArrayList<Account> accounts) {
        for (int i = 0; i < accounts.size(); i++) {
            Account acc = accounts.get(i);
            if (acc.getCardId().equals(cardId)) {
                return acc;
            }
        }
        return null; // 查无此账户
    }

    /**
     * 展示账户信息
     *
     * @param acc
     */
    public static void showAccount(Account acc,int []room) {
        System.out.println("===================当前账户信息如下========================");
        System.out.println("卡号：" + acc.getCardId());
        System.out.println("户主：" + acc.getUserName());
        System.out.println("余额：" + acc.getMoney());
        System.out.println("您的房间号如下：");
        String p=acc.getCardId();
        Integer myInt=Integer.parseInt(p);
        for (int i = 0; i < 100; i++) {
            if (room[i]==myInt){
                System.out.println("您的房间号是："+i);
            }
        }

    }

    /**
     * 为账户生成8位与其他账户卡号不同的号码。
     *
     * @return
     */
    public static String getRandomCardId(ArrayList<Account> accounts) {
        Random r = new Random();
        while (true) {
            // 1、先生成8位数字
            String cardId = ""; // 03442522
            for (int i = 0; i < 8; i++) {
                cardId += r.nextInt(10);
            }

            // 2、判断这个8位的卡号是否与其他账户的卡号重复了。
            // 根据这个卡号去查询账户的对象
            Account acc = Tool.getAccountByCardId(cardId, accounts);
            if (acc == null) {
                // 说明cardId 此时没有重复，这个卡号是一个新卡号了，可以使用这个卡号作为新注册账户的卡号了
                return cardId;
            }
        }
    }

    /**
     * 销户功能
     *
     * @param acc
     * @param sc
     * @param accounts
     */
    public static boolean deleteAccount(Account acc, Scanner sc, ArrayList<Account> accounts) {
        System.out.println("===================用户销户========================");
        System.out.println("您真的要销户？y/n");
        String rs = sc.next();
        switch (rs) {
            case "y":
                // 真正的销户
                // 从当前账户集合中，删除当前账户对象，销毁就完成了。
                if (acc.getMoney() > 0) {
                    System.out.println("您账户中还有钱没有取完，不允许销户~");
                } else {
                    accounts.remove(acc);
                    System.out.println("您的账户销户完成~~");
                    return true; // 销户成功
                }
                break;
            default:
                System.out.println("好的，当前账户继续保留~");
        }
        return false;
    }

    /**
     * 存钱
     *
     * @param acc 当前账户对象
     * @param sc  扫描器
     */
    public static void saveMoney(Account acc, Scanner sc,int []room) {
        System.out.println("===================用户充值操作========================");
        System.out.println("请您输入充值金额：");
        double money = sc.nextDouble();

        // 更新账户余额：原来的钱 + 新存入的钱
        acc.setMoney(acc.getMoney() + money);
        System.out.println("恭喜您，存钱成功，当前账户信息如下：");
        showAccount(acc,room);
    }

    /**
     * 修改密码
     *
     * @param sc  扫描器
     * @param acc 当前登录成功的账户对象。
     */
    public static void updatePassWord(Scanner sc, Account acc) {
        System.out.println("===================用户密码修改========================");
        while (true) {
            System.out.println("请您输入当前密码：");
            String passWord = sc.next();
            // 1、判断这个密码是否正确
            if (acc.getPassWord().equals(passWord)) {
                while (true) {
                    // 密码正确
                    // 2、输入新密码。
                    System.out.println("请您输入新密码：");
                    String newPassWord = sc.next();

                    System.out.println("请您确认新密码：");
                    String okPassWord = sc.next();

                    if (newPassWord.equals(okPassWord)) {
                        // 2次密码一致，可以修改了
                        acc.setPassWord(newPassWord);
                        System.out.println("恭喜您，您密码修改成功了~~");
                        return;
                    } else {
                        System.out.println("您输入的2次密码不一致~~");
                    }
                }
            } else {
                System.out.println("您输入的密码不正确~");
            }
        }
    }

    /**开房操作
     *
     * @param sc
     * @param room
     * @param acc
     * @param s
     * @param s2
     * @param s3
     */
    public static void getRoom(Scanner sc, int[] room,Account acc,Room s,Room s2,Room s3) {
        System.out.println("===================开房操作页=====================");
        System.out.println("请问您需要开什么类型的房间呢？");
        System.out.println("1、单人间,一天"+s.getPrice()+"元");
        System.out.println("2、双人间,一天"+s2.getPrice()+"元");
        System.out.println("3、总统套房，一天"+s3.getPrice()+"元");

        int select = sc.nextInt();
        switch (select) {
            case 1:
                // 单人间
               int a=1;
               double x=0.8;
               double x2=1.0;
                System.out.println("您是会员吗？请输入1代表yes 或 输入2代表no: ");
               int v=sc.nextInt();
               if (v==1){
                   getRoomNumber(sc,room,s,acc,a,x);
               }else {
                   getRoomNumber(sc,room,s,acc,a,x2);
               }
                break;
            case 2:
                //双人间
               int b=2;
               double y=0.8;
               double y2=1.0;
                System.out.println("您是会员吗？请输入1代表yes 或 输入2代表no: ");
                int v2=sc.nextInt();
                if (v2==1){
                    getRoomNumber(sc,room,s2,acc,b,y);
                }else {
                    getRoomNumber(sc,room,s2,acc,b,y2);
                }
                break;
            case 3:
                //总统套房
                int c=3;
                double z=0.8;
                double z2=1.0;
                System.out.println("您是会员吗？请输入1代表yes 或 输入2代表no: ");
                int v3=sc.nextInt();
                if (v3==1){
                    getRoomNumber(sc,room,s3,acc,c,z);
                }else {
                    getRoomNumber(sc,room,s,acc,c,z2);
                }
                break;
            default:
                System.out.println("您输入的操作命令不正确~~");
        }
    }

    /**开房方法
     *
     * @param sc
     * @param room
     *
     * @param s
     * @param acc
     * @param a
     */
    public static void getRoomNumber(Scanner sc,int []room,Room s,Account acc,int a,double m){
        System.out.println("请问你需要开几间房间呢？");
        int much=sc.nextInt();
        if( acc.getMoney()< much*m*s.getPrice()) {
            System.out.println("对不起，当前账户中钱不够，不能开房,请先充值~");
            return;
        }
        for (int i = 0; i < 100; i++) {
            String p=acc.getCardId();
            Integer myInt=Integer.parseInt(p);
            if(room[i]==a){
                for (int j = i; j <much+i ; j++) {
                    System.out.println("开房成功！房间号是"+j);
                    room[j]=myInt;
                }
                double v = acc.getMoney() - much *m* s.getPrice();
                acc.setMoney(v);
                return;
            }
        }
        System.out.println("已经没有"+s.getName()+"！");
    }

    /**退房操作
     *
     * @param sc
     * @param room
     * @param s
     * @param s2
     * @param s3
     */
    public static void checkOut(Scanner sc,int[] room,Room s,Room s2,Room s3,Account acc) {
        System.out.println("===================退房操作页=====================");
        System.out.println("请问您需要退什么类型的房间呢？");
        System.out.println("1、单人间");
        System.out.println("2、双人间");
        System.out.println("3、总统套房");
        int select = sc.nextInt();
        switch (select) {
            case 1:
                // 单人间
                int a=1;
                checkOutNumber(sc,room,a,acc);
                break;
            case 2:
                //双人间
                int a2=2;
                checkOutNumber(sc,room,a2,acc);
                break;
            case 3:
                //总统套房
                int a3=3;
                checkOutNumber(sc,room,a3,acc);
                break;
            default:
                System.out.println("您输入的操作命令不正确~~");
        }

    }

    /**退房方法
     *
     * @param sc
     * @param room
     * @param a
     */
    public  static  void checkOutNumber(Scanner sc,int []room,int a,Account acc) {
        String p=acc.getCardId();
        Integer myInt=Integer.parseInt(p);
        System.out.println("请输入您的房间号：");
        int n=sc.nextInt();
        if(room[n]!=myInt){
            System.out.println("该房间还未入住，您输入错误！");
            return;
        }
        room[n]=a;
        System.out.println("退房成功，欢迎下次光临！");
    }

    /**办理会员卡
     *
     * @param sc
     * @param acc
     */
    public static void member(Scanner sc,Account acc){
        System.out.println("===================办理会员操作页=====================");
        System.out.println("办卡需要缴费100，您确定要办理吗？请输入1代表yes 或 输入2代表no：");
        int w=sc.nextInt();
        if(w==1){
            if( acc.getMoney()< 100) {
                System.out.println("对不起，当前账户中钱不够，不能办理会员,请先充值~");
            }else {
                double v=acc.getMoney() - 100;
                acc.setMoney(v);
                System.out.println("您办理会员卡成功，感谢您的信任！");
            }
        }else {
            System.out.println("好的，您没有办卡成功！");
        }
    }

    /**查看空闲房间
     *
     * @param room
     * @param s
     * @param s2
     * @param s3
     */
    public static void viewRoom(int[] room, Room s, Room s2, Room s3) {
        int a=0,b=0,c=0;
        for (int i = 0; i < 100; i++) {
            if (room[i]==1){
                a++;
            }else if(room[i]==2){
                b++;
            }else if (room[i]==3){
                c++;
            }else{
                continue;
            }
        }
        System.out.println("===================当前空闲房间信息如下========================");
        System.out.println("单人间：" +a+"间   "+s.getPrice()+"元一天" );
        System.out.println("双人间：" +b+"间   "+s2.getPrice()+"元一天");
        System.out.println("总统套房:" +c+"间   "+s3.getPrice()+"元一天" );
    }


    public static String advice(Scanner sc) {
        String m=sc.next();
        return m;

    }
}
