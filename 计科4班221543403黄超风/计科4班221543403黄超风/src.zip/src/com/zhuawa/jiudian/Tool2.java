package com.zhuawa.jiudian;

import com.sun.deploy.cache.BaseLocalApplicationProperties;
import com.sun.deploy.util.JVMParameters;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

        //管理者操作的分步流程
public abstract class Tool2 {
    /**
     * 查询所有用户信息
     * @param accounts
     * @param room
     */
    public static void getInformation(ArrayList<Account> accounts, int[] room,Account acc) {
        System.out.println("===================查询所有用户信息操作页=====================");
        for (int i = 0; i < accounts.size(); i++) {
            Account s = accounts.get(i);
            if(s.getCardId()== acc.getCardId()){
                continue;
            }
            System.out.println("卡号： "+s.getCardId());
            System.out.println("户主： " + s.getUserName());
            System.out.println("余额：" + s.getMoney());
            System.out.println(s.getUserName()+"的房间号如下：");
            String p=s.getCardId();
            Integer myInt=Integer.parseInt(p);
            for (int j = 0; j< 100; j++) {
                if (room[j]==myInt){
                    System.out.println("房间号是："+j);
                }
            }
            System.out.println("---------------------");
        }
    }

    /**建造房屋
     *
     * @param sc
     * @param room
     */
    public static void buildRoom(Scanner sc, int[] room) {
        System.out.println("===================建造房屋操作页=====================");
        System.out.println("请问您需要建造什么类型的房间呢？");
        System.out.println("1、单人间");
        System.out.println("2、双人间");
        System.out.println("3、总统套房");
        int select = sc.nextInt();
        switch (select) {
            case 1:
                // 单人间
                int a=1;
                buildRoomNumber(sc,room,a);
                break;
            case 2:
                //双人间
                int a2=2;
                buildRoomNumber(sc,room,a2);
                break;
            case 3:
                //总统套房
                int a3=3;
                buildRoomNumber(sc,room,a3);
                break;
            default:
                System.out.println("您输入的操作命令不正确~~");
        }

    }

    /**建造房屋数量
     *
     * @param sc
     * @param room
     * @param a
     */
    public static void buildRoomNumber(Scanner sc, int[] room, int a) {
        System.out.println("请问您想要建造多少房间？");
        int many=sc.nextInt();
        for (int i = 0; i < many; i++) {
            for (int j = 0; j < 100; j++) {
                if(room[j]==0){
                    room[j]=a;
                    break;
                }else{
                    continue;
                }
            }
        }
        System.out.println("房间建造完成！");
    }

    /**拆除房间
     *
     * @param sc
     * @param room
     */
    public static void demolish(Scanner sc, int[] room) {
        System.out.println("===================拆除房屋操作页=====================");
        System.out.println("请问您想要拆除什么类型的房间呢？");
        System.out.println("1、单人间");
        System.out.println("2、双人间");
        System.out.println("3、总统套房");
        int select = sc.nextInt();
        switch (select) {
            case 1:
                // 单人间
                int a=1;
                demolishNumber(sc,room,a);
                break;
            case 2:
                //双人间
                int a2=2;
                demolishNumber(sc,room,a2);
                break;
            case 3:
                //总统套房
                int a3=3;
                demolishNumber(sc,room,a3);
                break;
            default:
                System.out.println("您输入的操作命令不正确~~");
        }

    }

    /**拆除房间数量
     *
     * @param sc
     * @param room
     * @param a
     */
    public static void demolishNumber(Scanner sc, int[] room, int a) {
        System.out.println("请问您想要拆除多少房间？");
        int many=sc.nextInt();
        for (int i = 0; i < many; i++) {
                for (int j = 0; j < 100; j++) {
                    if(room[j]==a){
                        room[j]=0;
                        break;
                     }else{
                       continue;
                    }
            }
        }
        System.out.println("房间拆除完成！");
    }

    /**装修房间
     *
     * @param sc
     * @param room
     */
    public static void renovation(Scanner sc, int[] room) {
        System.out.println("===================装修房屋操作页=====================");
        System.out.println("请问您想要如何装修？");
        System.out.println("1、单人间==>双人间");
        System.out.println("2、双人间==>总统套房");
        System.out.println("3、单人间==>总统套房");
        int select = sc.nextInt();
        int a=1,a2=2,a3=3;
        switch (select) {
            case 1:
                // 单人间
                renovationRoom(sc,room,a,a2);
                break;
            case 2:
                //双人间
                renovationRoom(sc,room,a2,a3);
                break;
            case 3:
                //总统套房
                renovationRoom(sc,room,a,a3);
                break;
            default:
                System.out.println("您输入的操作命令不正确~~");
        }

    }

    /**装修房间数量
     *
     * @param sc
     * @param room
     * @param a
     * @param b
     */
    public static void renovationRoom(Scanner sc, int[] room, int a,int b) {
        System.out.println("请问您想要装修多少房间？");
        int many=sc.nextInt();
        for (int i = 0; i < many; i++) {
            for (int j = 0; j < 100; j++) {
                if(room[j]==a){
                    room[j]=b;
                    break;
                }else{
                    continue;
                }
            }
        }
        System.out.println("房间装修完成！");
    }
}
