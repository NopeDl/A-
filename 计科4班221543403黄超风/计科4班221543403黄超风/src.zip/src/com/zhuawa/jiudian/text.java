package com.zhuawa.jiudian;

import java.util.ArrayList;
import java.util.Scanner;

public class text {
    public static void main(String[] args) {
        // 1、定义账户类
        // 2、定义一个集合容器，负责以后存储全部的账户对象，进行相关的业务操作。
        ArrayList<Account> accounts= new ArrayList<>();
        Room s=new Single(150,"单人间");
        Room s2=new Double(200,"双人间");
        Room s3=new Suite(300,"总统套房");

        int[]room=new int[100];
        for(int i=0;i<20;i++){
            room[i]=1;
        }
        for(int i=20;i<30;i++){
            room[i]=2;
        }
        for(int i=30;i<40;i++){
            room[i]=3;
        }

        Scanner sc = new Scanner(System.in);
        // 3、展示系统的首页
        while (true) {
            System.out.println("===============欢迎使用旅馆小帮手=================");
            System.out.println("1、登录");
            System.out.println("2、注册");
            System.out.println("3、退出");
            System.out.println("请您选择操作：");
            int command = sc.nextInt();
            switch (command){
                case 1:
                    // 1、判断账户集合中是否存在账户，如果不存在账户，登录功能不能进行。
                    if(accounts.size() == 0) {
                        System.out.println("对不起，当前系统中，无任何账户，请先开户，再来登录~~");
                        break; // 卫语言风格，解决方法的执行。
                    }
                    System.out.println("===============欢迎使用旅馆小帮手=================");
                    System.out.println("请问您是？");
                    System.out.println("1、顾客");
                    System.out.println("2、管理者");
                    System.out.println("请您选择操作：");
                    int people=sc.nextInt();
                    switch (people){
                        case 1:
                            //顾客
                            login( accounts, sc,room,s,s2,s3);
                            break;
                        case 2:
                            //管理者
                            manage( accounts, sc,room,s,s2,s3);
                            break;
                        default:
                            System.out.println("您输入的操作命令不存在~~");
                        }
                    break;
                case 2:
                    // 注册(ALT + ENTER)
                    System.out.println("===============欢迎使用旅馆小帮手=================");
                    System.out.println("请问您是？");
                    System.out.println("1、顾客");
                    System.out.println("2、管理者");
                    System.out.println("请您选择操作：");
                    int person=sc.nextInt();
                    switch (person){
                        case 1:
                        case 2:
                            //管理者
                            register(accounts,sc);
                            break;
                        default:
                            System.out.println("您输入的操作命令不存在~~");
                    }
                    break;
                case 3:
                    //退出
                    System.out.println("退出成功，欢迎下次光临！");
                    break;
                default:
                    System.out.println("您输入的操作命令不存在~~");
            }
        }
    }
    /**
     * 用户开户功能的实现
     * @param accounts 接收的账户集合。
     */
    private static void register(ArrayList<Account> accounts, Scanner sc) {
        System.out.println("===================系统开户操作========================");
        // 1、创建一个账户对象，用于后期封装账户信息。
        Account account = new Account();

        // 2、录入当前这个账户的信息，注入到账户对象中去。
        System.out.println("请您输入账户用户名：");
        String userName = sc.next();
        account.setUserName(userName);

        while (true) {
            System.out.println("请您输入账户密码：（密码最好多于6位）");
            String passWord = sc.next();
            System.out.println("请您输入确认密码：");
            String okPassWord = sc.next();
            if(okPassWord.equals(passWord)){
                // 密码认证通过，可以注入给账户对象
                account.setPassWord(okPassWord);
                break; // 密码已经录入成功了，死循环没有必要继续了！
            }else {
                System.out.println("对不起，您输入的2次密码不一致，请重新确认~~");
            }
        }

        // 为账户随机一个8位且与其他账户的卡号不重复的号码。(独立功能，独立成方法)。
        String cardId = Tool.getRandomCardId(accounts);
        account.setCardId(cardId);

        // 3、把账户对象添加到账户集合中去。
        accounts.add(account);
        System.out.println("恭喜您，" +userName + "先生/女士，您开户成功，您的卡号是：" + cardId + "，请您妥善保管卡号" );
    }


    /**
     * 顾客登录功能
     *
     * @param accounts 全部账户对象的集合
     * @param sc       扫描器
     * @param s2
     * @param s3
     */
    private static void login(ArrayList<Account> accounts, Scanner sc, int [] room, Room s, Room s2, Room s3) {
        System.out.println("===================系统登录操作========================");
        // 1、判断账户集合中是否存在账户，如果不存在账户，登录功能不能进行。
        if(accounts.size() == 0) {
            System.out.println("对不起，当前系统中，无任何账户，请先开户，再来登录~~");
            return; // 卫语言风格，解决方法的执行。
        }

        // 2、正式进入登录操作
        while (true) {
            System.out.println("请您输入登录卡号：");
            String cardId = sc.next();
            // 3、判断卡号是否存在：根据卡号去账户集合中查询账户对象。
            Account acc = Tool.getAccountByCardId(cardId, accounts);
            if(acc != null){
                while (true) {
                    // 卡号存在的,acc成为一个地址
                    // 4、让用户输入密码，认证密码
                    System.out.println("请您输入登录密码：");
                    String passWord = sc.next();
                    // 判断当前账户对象的密码是否与用户输入的密码一致
                    if(acc.getPassWord().equals(passWord)) {
                        // 登录成功了
                        System.out.println("恭喜您，" + acc.getUserName() +"先生/女生进入系统，您的卡号是：" + acc.getCardId());
                        // .... 查询 转账 取款 ....
                        // 展示登录后的操作页。
                        showUserCommand(accounts, acc, sc,room,s,s2,s3);
                        return; // 干掉登录方法
                    }else {
                        System.out.println("对不起，您输入的密码有误~~");
                    }
                }
            }else {
                System.out.println("对不起，系统中不存在该账户卡号~~");
            }
        }

    }
    /**
     展示顾客登录后的操作页
     */
    private static void showUserCommand(ArrayList<Account> accounts, Account acc, Scanner sc,int [] room,Room s,Room s2,Room s3) {
        while (true) {
            System.out.println("===================顾客操作页=====================");
            System.out.println("================欢迎使用旅馆小帮手==================");
            System.out.println("1、查询我的房卡");
            System.out.println("2、开房");
            System.out.println("3、退房");
            System.out.println("4、充值");
            System.out.println("5、查看空闲房间");
            System.out.println("6、退出登录");
            System.out.println("7、注销账户");
            System.out.println("8、办会员卡，将享受八折优惠");
            System.out.println("9、修改密码");
            System.out.println("请选择：");
            int command = sc.nextInt();
            switch (command) {
                case 1:
                    // 查询账户(展示当前登录的账户信息)
                    Tool.showAccount(acc,room);
                    break;
                case 2:
                    // 开房
                    Tool.getRoom(sc,room,acc,s,s2,s3);
                    break;
                case 3:
                    // 退房
                    Tool.checkOut(sc,room,s,s2,s3,acc);

                    break;
                case 4:
                    // 充值
                    Tool.saveMoney(acc, sc,room);
                    break;
                case 5:
                    // 查看空闲房间
                    Tool.viewRoom(room,s,s2,s3);
                    break;
                case 6:
                    // 退出登录
                    System.out.println("退出成功，欢迎下次光临");
                    return; // 让当前方法停止执行，跳出去
                case 7:
                    // 注销账户
                    if(Tool.deleteAccount(acc,sc,accounts)) {
                        // 销户成功了，回到首页
                        return; // 让当前方法停止执行，跳出去
                    } else {
                        // 没有销户成功， 还是在操作页玩
                        System.out.println("您的账户保留！");
                        break;
                    }
                case 8:
                    //办会员卡
                    Tool.member(sc,acc);
                    break;
                case 9:
                    //修改密码
                    Tool.updatePassWord(sc, acc);
                    return; // 让当前方法停止执行，跳出去
                default:
                    System.out.println("您输入的操作命令不正确~~");
            }
        }
    }


    /**
     * 管理者登录功能
     *
     * @param accounts 全部账户对象的集合
     * @param sc       扫描器
     */
    private static void manage(ArrayList<Account> accounts, Scanner sc,int []room,Room s,Room s2,Room s3) {
        System.out.println("===================系统登录操作========================");
        // 1、判断账户集合中是否存在账户，如果不存在账户，登录功能不能进行。
        if(accounts.size() == 0) {
            System.out.println("对不起，当前系统中，无任何账户，请先开户，再来登录~~");
            return; // 卫语言风格，解决方法的执行。
        }

        // 2、正式进入登录操作
        while (true) {
            System.out.println("请您输入登录卡号：");
            String cardId = sc.next();
            // 3、判断卡号是否存在：根据卡号去账户集合中查询账户对象。
            Account acc = Tool.getAccountByCardId(cardId, accounts);
            if(acc != null){
                while (true) {
                    // 卡号存在的
                    // 4、让用户输入密码，认证密码
                    System.out.println("请您输入登录密码：");
                    String passWord = sc.next();
                    // 判断当前账户对象的密码是否与用户输入的密码一致
                    if(acc.getPassWord().equals(passWord)) {
                        // 登录成功了
                        System.out.println("恭喜您，" + acc.getUserName() +"先生/女生进入系统，您的卡号是：" + acc.getCardId());
                        // .... 查询 转账 取款 ....
                        // 展示登录后的操作页。
                        showManageCommand(accounts, acc, sc,room,s,s2,s3);
                        return; // 干掉登录方法
                    }else {
                        System.out.println("对不起，您输入的密码有误~~");
                    }
                }
            }else {
                System.out.println("对不起，系统中不存在该账户卡号~~");
            }
        }

    }
    /**
     展示管理者登录后的操作页
     */
    private static void showManageCommand(ArrayList<Account> accounts, Account acc, Scanner sc,int []room,Room s,Room s2,Room s3) {
        while (true) {
            System.out.println("===================管理者操作页=====================");
            System.out.println("================欢迎使用旅馆小帮手==================");
            System.out.println("1、查询所有用户信息");
            System.out.println("2、建造");
            System.out.println("3、拆除");
            System.out.println("4、装修");
            System.out.println("5、修改密码");
            System.out.println("6、退出");
            System.out.println("7、注销账户");
            System.out.println("8、查看空闲房间");
            System.out.println("请选择：");
            int command = sc.nextInt();
            switch (command) {
                case 1:
                    // 查询所有账户信息
                    Tool2.getInformation(accounts,room,acc);
                    break;
                case 2:
                    // 建造
                    Tool.viewRoom(room,s,s2,s3);
                    Tool2.buildRoom(sc,room);
                    break;
                case 3:
                    // 拆除
                    Tool.viewRoom(room,s,s2,s3);
                    Tool2.demolish(sc,room);
                    break;
                case 4:
                    // 装修
                    Tool.viewRoom(room,s,s2,s3);
                    Tool2.renovation(sc,room);
                    break;
                case 5:
                    // 修改密码
                    Tool.updatePassWord(sc, acc);
                    return; // 让当前方法停止执行，跳出去
                case 6:
                    // 退出
                    System.out.println("退出成功，欢迎下次光临");
                    return; // 让当前方法停止执行，跳出去
                case 7:
                    // 注销账户
                    if(Tool.deleteAccount(acc,sc,accounts)){
                        // 销户成功了，回到首页
                        return; // 让当前方法停止执行，跳出去
                    }else {
                        // 没有销户成功， 还是在操作页玩
                        break;
                    }
                case 8:
                    //查看空闲房间
                    Tool.viewRoom(room,s,s2,s3);
                default:
                    System.out.println("您输入的操作命令不正确~~");
            }
        }
    }
}


